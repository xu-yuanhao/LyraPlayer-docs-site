# Lyra Player Plugin SDK 2

Lyra Player 是闭源播放器。本包仅包含开发插件所需的公开 C 声明、示例和编译脚本，不包含宿主实现或签名凭据。

Linux、Android NDK 28.2.13676358、Python 3.11+；设置 ANDROID_HOME 后执行 `bash examples/build.sh`。
产物在 out/examples/，通过 Lyra 设置中的安装插件选择 ZIP。先使用 style/rules；根示例接管整个 UI，可能隐藏默认设置入口。

接口 version 2，ABI 1 不支持。查询缺失能力返回 NULL；按公开线程、所有权和 size 约定使用。Android arm64-v8a / API 26+，不含 PC 宿主。

SDK/示例的授权范围依项目方正式条款，不授予 Lyra Player 私有实现源码的权利。文档站点中第三方框架的 MIT 许可不改变宿主许可。

Android clients use sdk/android-platform-v1.json: check lyraPlatformVersion()==1 before resolving exact JNI descriptors. Service handle lifetime and revocation are specified in service_contracts.h. No older Android contract or handle adaptation is provided.
