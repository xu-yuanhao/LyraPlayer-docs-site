#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
sdk_root="${ANDROID_HOME:-$HOME/Android/Sdk}"
ndk_version="${LYRA_NDK_VERSION:-28.2.13676358}"
toolchain="$sdk_root/ndk/$ndk_version/toolchains/llvm/prebuilt/linux-x86_64/bin"
compiler="$toolchain/aarch64-linux-android26-clang"
[[ -x "$compiler" ]] || { echo "Missing Linux NDK compiler: $compiler" >&2; exit 1; }
for variant in root style rules; do
  destination="out/examples/example.$variant"
  mkdir -p "$destination"
  "$compiler" -std=c11 -Oz -fPIC -fvisibility=hidden -shared -I sdk/include "examples/$variant.c" -o "$destination/plugin.so"
  "$toolchain/llvm-readelf" -h "$destination/plugin.so" | rg -q 'AArch64'
  "$toolchain/llvm-nm" -D "$destination/plugin.so" | rg -q ' T lyra_plugin_init$'
  kind=frame
  [[ "$variant" == style ]] && kind=style
  [[ "$variant" == rules ]] && kind=playback-rules
  printf 'id = "example.%s"\nversion = "1.0"\nabi = 3\ntype = "%s"\nentry = "plugin.so"\n' "$variant" "$kind" > "$destination/manifest.toml"
  python3 - "$destination" <<'PY'
import pathlib,sys,zipfile
root=pathlib.Path(sys.argv[1]);target=root.with_suffix(root.suffix+'.zip')
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted(root.iterdir()):z.write(path,path.name)
print(target)
PY
done
